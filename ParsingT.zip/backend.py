from unicodedata import name
import ParsingT
import tokenizer
class node:
    name=""
    adjacentlist=[]
    def __init__(self,name):
        self.name=name
        self.adjacentlist=[]
    def add2adjacentlist(self,node):
        self.adjacentlist.append(node)

class tree:
    def __init__(self,listofnodes):
        self.listofnodes=listofnodes

def checkinput(inputstring):
    intokenlist=tokenizer.token(inputstring)
    intokenlist.append("$")
    intokenlist.reverse()  
    currstate="EXP"
    nextstate=None
    listfortree=[]
    #headnode.add2adjacentlist("EXP'",TERM)
    statelist=["$","EXP"]
    while True:
        if len(statelist)==1 and len(intokenlist)==1 and statelist[0]=="$" and intokenlist[0]=="$" :
            print("--------------------------------------------------")
            for i in range(len(listfortree)):
                 print(listfortree[i].name)
                 print(listfortree[i].adjacentlist)
            print("--------------------------------------------------")
            return "accepted"
        tupeoftokenizer=intokenlist[-1]
        typeofstart=tupeoftokenizer[0]
        currstate=statelist.pop()
        currstatenode=node(currstate)
        if currstate==typeofstart:
            currstatenode.add2adjacentlist(tupeoftokenizer[1])
            listfortree.append(currstatenode)
            intokenlist.pop()
            print(intokenlist)
            print(statelist)
            continue
        print(typeofstart)
        nextstate=ParsingT.ruletranslation(ParsingT.parsingTable(currstate,typeofstart))
        if nextstate=="EPI":
             print(statelist)
             continue
        if nextstate==-1:
             print(currstate)
             return "refused"
        templist=nextstate.split(" ")
        templist.reverse()
        for i in range(len(templist)):
            statelist.append(templist[i])
        templist.reverse()
        for i in range(len(templist)):
            currstatenode.add2adjacentlist(templist[i])
            #node(templist[i],currstate)
        templist.reverse()
        listfortree.append(currstatenode)
        print(statelist)
        print(intokenlist)
    
   
print(checkinput("!!!!x>y||!!!!!z>!!!!!u&&x<i||u<i||i<o&&m>w"))